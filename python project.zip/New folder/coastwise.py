import pandas as pdjuju7yuj7jyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyjjjjjm8i9o00p09
import plotly.graph_objects as go
import streamlit as st

st.set_page_config(page_title="Coastwise Intelligence", page_icon="◒", layout="wide", initial_sidebar_state="expanded")

LANGUAGES = {
    "English": {"site": "MONITORING SITE", "layer": "MAP LAYER", "layers": ["Composite risk", "Vegetation health", "Coastline change"], "kicker": "COASTAL OBSERVATORY / LIVE WORKSPACE", "title": "See the coast<br>before it shifts.", "intro": "AI-assisted monitoring for erosion, habitat stress, and environmental risk across India's vulnerable shoreline.", "nominal": "SYSTEMS NOMINAL", "snapshot": "Selected zone / analysis snapshot", "risk": "COASTAL RISK INDEX", "shore": "SHORELINE SHIFT", "vegetation": "VEGETATION COVER", "water": "WATER QUALITY", "retreat": "Retreat signal detected", "field_note": "AI FIELD NOTE / 08:42 UTC", "observation": "The model identifies a <b>{shore:.1f} m annualized shoreline retreat</b> in the northern transect. Sediment loss is likely accelerating after two high-energy tide events.", "recommendation": "Recommendation: prioritize dune reinforcement and inspect the 2.4 km transect before the next spring tide.", "geospatial": "Geospatial intelligence", "signals": "Signals over time", "active": "Active signals", "model": "MODEL STATUS  /  ONLINE", "sync": "Last sync  19 Aug 2026 · 06:40 UTC", "annualized": "annualized retreat", "baseline": "↓ 0.04 vs baseline", "watch": "within watch range", "trend": "NDVI", "risk_axis": "Risk %", "prototype": "Prototype insight layer uses representative observations. Connect Sentinel, PostGIS, and the prediction service to replace sample feeds with live data."},
    "हिन्दी": {"site": "निगरानी स्थल", "layer": "मानचित्र परत", "layers": ["समग्र जोखिम", "वनस्पति स्वास्थ्य", "तटरेखा परिवर्तन"], "kicker": "तटीय वेधशाला / लाइव कार्यक्षेत्र", "title": "तट को देखें<br>बदलने से पहले।", "intro": "भारत के संवेदनशील तट पर कटाव, आवास तनाव और पर्यावरणीय जोखिम की AI-सहायित निगरानी।", "nominal": "सिस्टम सामान्य", "snapshot": "चयनित क्षेत्र / विश्लेषण सारांश", "risk": "तटीय जोखिम सूचकांक", "shore": "तटरेखा बदलाव", "vegetation": "वनस्पति आवरण", "water": "जल गुणवत्ता", "retreat": "पीछे हटने का संकेत मिला", "field_note": "AI फील्ड नोट / 08:42 UTC", "observation": "मॉडल उत्तरी ट्रांसेक्ट में <b>{shore:.1f} मीटर वार्षिक तटरेखा पीछे हटना</b> दिखाता है। दो तेज ज्वार घटनाओं के बाद तलछट हानि बढ़ सकती है।", "recommendation": "सुझाव: अगले वसंत ज्वार से पहले टीलों को मजबूत करें और 2.4 किमी ट्रांसेक्ट का निरीक्षण करें।", "geospatial": "भौगोलिक बुद्धिमत्ता", "signals": "समय के साथ संकेत", "active": "सक्रिय संकेत", "model": "मॉडल स्थिति / ऑनलाइन", "sync": "अंतिम सिंक 19 अगस्त 2026 · 06:40 UTC", "annualized": "वार्षिक पीछे हटना", "baseline": "↓ 0.04 आधार रेखा से", "watch": "निगरानी सीमा में", "trend": "NDVI", "risk_axis": "जोखिम %", "prototype": "प्रोटोटाइप परत प्रतिनिधि आंकड़ों का उपयोग करती है। लाइव फीड के लिए Sentinel, PostGIS और prediction service जोड़ें।"},
    "తెలుగు": {"site": "పర్యవేక్షణ ప్రదేశం", "layer": "మ్యాప్ లేయర్", "layers": ["మొత్తం ప్రమాదం", "వృక్ష ఆరోగ్యం", "తీరరేఖ మార్పు"], "kicker": "తీర పరిశీలనా కేంద్రం / లైవ్ వర్క్‌స్పేస్", "title": "తీరాన్ని చూడండి<br>మారకముందే.", "intro": "భారతదేశంలోని సున్నితమైన తీరప్రాంతంలో కోత, నివాస ఒత్తిడి మరియు పర్యావరణ ప్రమాదాల AI పర్యవేక్షణ.", "nominal": "సిస్టమ్స్ సాధారణంగా ఉన్నాయి", "snapshot": "ఎంచుకున్న ప్రాంతం / విశ్లేషణ సారాంశం", "risk": "తీర ప్రమాద సూచిక", "shore": "తీరరేఖ మార్పు", "vegetation": "వృక్ష కవచం", "water": "నీటి నాణ్యత", "retreat": "తీరరేఖ వెనక్కి తగ్గే సంకేతం", "field_note": "AI ఫీల్డ్ నోట్ / 08:42 UTC", "observation": "మోడల్ ఉత్తర ట్రాన్సెక్ట్‌లో <b>{shore:.1f} మీటర్ల వార్షిక తీరరేఖ వెనక్కి తగ్గుదలను</b> గుర్తించింది. రెండు అధిక శక్తి ఆటుపోట్ల తర్వాత ఇసుక నష్టం పెరుగుతోంది.", "recommendation": "సూచన: తదుపరి స్ప్రింగ్ టైడ్‌కు ముందు ఇసుక దిబ్బలను బలోపేతం చేసి 2.4 కి.మీ ట్రాన్సెక్ట్‌ను పరిశీలించండి.", "geospatial": "భౌగోళిక మేధస్సు", "signals": "కాలక్రమంలో సంకేతాలు", "active": "క్రియాశీల సంకేతాలు", "model": "మోడల్ స్థితి / ఆన్‌లైన్", "sync": "చివరి సమకాలీకరణ 19 ఆగస్టు 2026 · 06:40 UTC", "annualized": "వార్షిక వెనక్కి తగ్గుదల", "baseline": "↓ 0.04 ప్రామాణిక స్థాయి నుండి", "watch": "పర్యవేక్షణ పరిధిలో", "trend": "NDVI", "risk_axis": "ప్రమాదం %", "prototype": "ప్రోటోటైప్ పొర ప్రతినిధి డేటాను ఉపయోగిస్తుంది. లైవ్ ఫీడ్‌ల కోసం Sentinel, PostGIS మరియు prediction service‌ను అనుసంధానించండి."},
}

language = st.sidebar.selectbox("LANGUAGE / भाषा / భాష", list(LANGUAGES))
text = LANGUAGES[language]

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Manrope:wght@400;600;700;800&display=swap');
html, body, [class*="css"] { font-family: 'Manrope', sans-serif; color: #172525; }
.stApp { background: #f4f1e9; }
[data-testid="stSidebar"] { background: #173c3c; border-right: 0; }
[data-testid="stSidebar"] * { color: #e9f5ed !important; }
.kicker, .section-label { color: #39817c; font: 500 11px 'DM Mono', monospace; letter-spacing: 1.5px; text-transform: uppercase; }
.hero { display:flex; justify-content:space-between; align-items:end; padding: 1rem 0 1.5rem; border-bottom:1px solid #d9e2dc; }
.hero h1 { font-size:42px; line-height:1.05; letter-spacing:-1.5px; margin:8px 0; color:#172525; font-weight:700; }
.hero p { color:#667777; margin:0; max-width:620px; }
.status { background:#d8f3df; color:#23704b; padding:8px 12px; border-radius:4px; font:500 11px 'DM Mono',monospace; }
.metric-card { background:#fff; border:1px solid #d9e2dc; border-radius:6px; padding:18px; min-height:106px; }
.metric-card { background:#fff; border:1px solid #d9e2dc; border-radius:4px; font:500 11px 'DM Mono'; }
.metric-card { color:#172525; }
.metric-card * { color:#172525; }
.metric-value { font-size:30px; font-weight:800; margin:8px 0 4px; }
.metric-delta { color:#39817c; font:500 11px 'DM Mono',monospace; }
.section-label { margin:22px 0 10px; color:#66817c; }
.insight { background:#173c3c; color:#eaf7ee; border-radius:6px; padding:20px; }
.insight h3 { color:#a7e7c5; margin:0 0 10px; font-size:17px; }
.insight p { font-size:13px; line-height:1.6; }
.insight small { color:#a6c8bd; font-family:'DM Mono',monospace; }
</style>
""", unsafe_allow_html=True)

sites = {
    "Visakhapatnam / Bay of Bengal": {"lat": 17.6868, "lon": 83.2185, "risk": 68, "shore": -14.2, "ndvi": 0.64, "water": 71},
    "Chennai / Marina Coast": {"lat": 13.0827, "lon": 80.2707, "risk": 54, "shore": -8.6, "ndvi": 0.58, "water": 63},
    "Kakinada / Godavari Delta": {"lat": 16.9891, "lon": 82.2475, "risk": 77, "shore": -19.8, "ndvi": 0.71, "water": 58},
    "Mumbai / Arabian Sea": {"lat": 19.0760, "lon": 72.8777, "risk": 43, "shore": -5.2, "ndvi": 0.49, "water": 46},
}
site_name = st.sidebar.selectbox(text["site"], list(sites))
site = sites[site_name]
st.sidebar.markdown("---")
st.sidebar.markdown("**COASTWISE**  \n*Intelligence platform*")
st.sidebar.caption("Sentinel-2 · Landsat 9 · Tide gauge feeds")
layer = st.sidebar.radio(text["layer"], text["layers"])
st.sidebar.markdown("---")
st.sidebar.caption(f"{text['model']}\n\n{text['sync']}")

st.markdown(f'<div class="hero"><div><div class="kicker">{text["kicker"]}</div><h1>{text["title"]}</h1><p>{text["intro"]}</p></div><div class="status">●  {text["nominal"]}</div></div>', unsafe_allow_html=True)
st.markdown(f'<div class="section-label">{text["snapshot"]}</div>', unsafe_allow_html=True)
metric_cols = st.columns(4)
cards = [(text["risk"], f"{site['risk']} / 100", "↑ 6.4% vs last quarter"), (text["shore"], f"{abs(site['shore']):.1f} m", text["annualized"]), (text["vegetation"], f"{site['ndvi']:.2f} NDVI", text["baseline"]), (text["water"], f"{site['water']} / 100", text["watch"])]
for column, (label, value, delta) in zip(metric_cols, cards):
    with column:
        st.markdown(f'<div class="metric-card"><div class="metric-label">{label}</div><div class="metric-value">{value}</div><div class="metric-delta">{delta}</div></div>', unsafe_allow_html=True)

st.markdown(f'<div class="section-label">{text["geospatial"]}</div>', unsafe_allow_html=True)
map_col, insight_col = st.columns([1.65, 1], gap="large")
with map_col:
    map_df = pd.DataFrame([{"lat": data["lat"], "lon": data["lon"], "risk": data["risk"]} for data in sites.values()])
    st.map(map_df, latitude="lat", longitude="lon", size="risk", color="#1e6b68", zoom=5)
    st.caption(f"{layer.upper()}  ·  {site_name}  ·  10 m satellite resolution  ·  12 Aug 2026")
with insight_col:
    st.markdown(f'<div class="insight"><small>{text["field_note"]}</small><h3>{text["retreat"]}</h3><p>{text["observation"].format(shore=abs(site["shore"]))}</p><p style="margin-bottom:0;color:#c4e3d2">{text["recommendation"]}</p></div>', unsafe_allow_html=True)

st.markdown(f'<div class="section-label">{text["signals"]}</div>', unsafe_allow_html=True)
trend_col, risk_col = st.columns([1.35, 1], gap="large")
months = ["Sep 25", "Nov 25", "Jan 26", "Mar 26", "May 26", "Jul 26", "Aug 26"]
with trend_col:
    trend = go.Figure(go.Scatter(x=months, y=[0.71, 0.69, 0.68, 0.66, 0.65, 0.63, site["ndvi"]], mode="lines+markers", line=dict(color="#1e6b68", width=3), marker=dict(size=7, color="#a7e7c5")))
    trend.update_layout(height=245, margin=dict(l=0,r=0,t=12,b=0), plot_bgcolor="#fff", paper_bgcolor="#fff", yaxis=dict(range=[0.4,0.8], title=text["trend"], gridcolor="#e7eeea"), xaxis=dict(showgrid=False), font=dict(family="Manrope", color="#667777"))
    st.plotly_chart(trend, use_container_width=True, config={"displayModeBar": False})
with risk_col:
    risk = go.Figure(go.Bar(x=["Erosion", "Flooding", "Pollution", "Habitat"], y=[82, 64, 48, 39], marker_color=["#e06f4e", "#e8b15d", "#6ba5a0", "#a7e7c5"]))
    risk.update_layout(height=245, margin=dict(l=0,r=0,t=12,b=0), plot_bgcolor="#fff", paper_bgcolor="#fff", yaxis=dict(range=[0,100], title=text["risk_axis"], gridcolor="#e7eeea"), xaxis=dict(showgrid=False), font=dict(family="Manrope", color="#667777"))
    st.plotly_chart(risk, use_container_width=True, config={"displayModeBar": False})

st.markdown(f'<div class="section-label">{text["active"]}</div>', unsafe_allow_html=True)
alerts = pd.DataFrame({"STATUS": ["HIGH", "WATCH", "WATCH"], "SIGNAL": ["Shoreline retreat above threshold", "Mangrove canopy density declining", "Turbidity spike after rainfall"], "DETECTED": ["12 Aug 2026", "09 Aug 2026", "07 Aug 2026"]})
st.dataframe(alerts, use_container_width=True, hide_index=True)
st.caption(text["prototype"])
